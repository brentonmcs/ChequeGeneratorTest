﻿namespace SPHealthChequeConverter.Models
{
    public class ChequeDisplayDetails : ChequeSubmitDetails
    {
        public string AmountInWords { get; set; }
    }
}